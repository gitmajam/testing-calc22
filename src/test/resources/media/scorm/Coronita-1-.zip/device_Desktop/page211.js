if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
image212.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj212Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1280px; height: 720px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1280px; height: 720px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"212",
	htmlId:		"tobj212",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,1280,720]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
og209.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og209",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape201.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj201inner\"><svg viewBox=\"0 0 1260 700\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(630 350)\" style=\"\">\n	<path d=\"M 0 0 L 1260 0 L 1260 700 L 0 700 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54); pointer-events: auto;\" transform=\"translate(0 0) translate(-630, -350) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(630 350)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"47.9999988\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54);\">\n			<tspan x=\"0\" y=\"15.12\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 10px; top: 10px; visibility: hidden; position: absolute; width: 1260px; height: 700px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"201",
	htmlId:		"tobj201",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,9.999999999999886,10.00000000000017,1,0],[9.999999999999886,10.00000000000017,1260,700]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":10,"y":10,"width":1260,"height":700},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text202.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 1021px; min-height: 392px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 1011px; min-height: 382px;\"><p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt; font-family: AzoSans-Bold, sans-serif; color: rgb(255, 255, 255);\">Ahora vamos a responder tres preguntas.</span></p>\n\n<p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt;\"><span style=\"font-family: AzoSans-Bold, sans-serif; font-size:36pt;\"><span style=\"color: rgb(255, 255, 255);\">Para avanzar a la siguiente actividad debes contestarlas todas correctamente.</span><br>\n<span style=\"color: rgb(255, 255, 255);\">Tienes&nbsp; &nbsp; &nbsp; &nbsp;intentos para lograrlo.</span></span></span></p></div></div>",
	cssText:	"left: 130px; top: 164px; visibility: hidden; position: absolute; width: 1021px; height: 392px; z-index: 3;",
	cssClasses:	"",
	id:		"202",
	htmlId:		"tobj202",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,130,164,1,0],[130,164,1021,392]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":164,"width":1021,"height":392},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text220.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 83px; min-height: 59px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 73px; min-height: 49px;\"><p style=\"text-align: center;\"><span style=\"font-size:36pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\"><span style=\"color: rgb(255, 255, 255);\">&nbsp;</span></span></p></div></div>",
	cssText:	"left: 423px; top: 404px; visibility: hidden; position: absolute; width: 83px; height: 59px; z-index: 4;",
	cssClasses:	"",
	id:		"220",
	htmlId:		"tobj220",
	bInsAnc:	0,
	cwObj:		{
		"name":	"variable",
		"arChld":
	[
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('1'))text220.changeContents( "3" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('2'))text220.changeContents( "2" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('3'))text220.changeContents( "1" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,423,404,1,0],[423,404,83,59]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":423,"y":404,"width":83,"height":59},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton203.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj203inner\"><svg viewBox=\"0 0 244 86\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(122 43)\" style=\"\">\n	<path d=\"M 21.25 0 L 221.75 0 A 21.25 21.25 0 0 1 243 21.25 L 243 63.75 A 21.25 21.25 0 0 1 221.75 85 L 21.25 85 A 21.25 21.25 0 0 1 0 63.75 L 0 21.25 A 21.25 21.25 0 0 1 21.25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-121.5, -42.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(122 43)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-55.14\" y=\"10.08\" fill=\"#FFFFFF\">Aceptar</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 518.5px; top: 527.5px; visibility: hidden; position: absolute; width: 244px; height: 86px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"203",
	htmlId:		"tobj203",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnEvaluacion",
		"arChld":
	[
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page39.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[36,32864,[37,0,6,0,0,0,518.5,527.5,1,0],[518.5,527.5,244,86]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":519,"y":528,"width":244,"height":86},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(122 43)\" style=\"\">\n\t<path d=\"M 21.25 0 L 221.75 0 A 21.25 21.25 0 0 1 243 21.25 L 243 63.75 A 21.25 21.25 0 0 1 221.75 85 L 21.25 85 A 21.25 21.25 0 0 1 0 63.75 L 0 21.25 A 21.25 21.25 0 0 1 21.25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-121.5, -42.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(122 43)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.14\" y=\"10.08\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(122 43)\" style=\"\">\n\t<path d=\"M 21.25 0 L 221.75 0 A 21.25 21.25 0 0 1 243 21.25 L 243 63.75 A 21.25 21.25 0 0 1 221.75 85 L 21.25 85 A 21.25 21.25 0 0 1 0 63.75 L 0 21.25 A 21.25 21.25 0 0 1 21.25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-121.5, -42.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(122 43)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.14\" y=\"10.08\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(122 43)\" style=\"\">\n\t<path d=\"M 21.25 0 L 221.75 0 A 21.25 21.25 0 0 1 243 21.25 L 243 63.75 A 21.25 21.25 0 0 1 221.75 85 L 21.25 85 A 21.25 21.25 0 0 1 0 63.75 L 0 21.25 A 21.25 21.25 0 0 1 21.25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-121.5, -42.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(122 43)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-55.14\" y=\"10.08\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(122 43)\" style=\"\">\n\t<path d=\"M 21.25 0 L 221.75 0 A 21.25 21.25 0 0 1 243 21.25 L 243 63.75 A 21.25 21.25 0 0 1 221.75 85 L 21.25 85 A 21.25 21.25 0 0 1 0 63.75 L 0 21.25 A 21.25 21.25 0 0 1 21.25 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-121.5, -42.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(122 43)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"31.9999992\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-55.14\" y=\"10.08\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
rcdObj.rcdData.att_Desktop = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	2
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/DPO_back6.jpg"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1280px; height: 720px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];

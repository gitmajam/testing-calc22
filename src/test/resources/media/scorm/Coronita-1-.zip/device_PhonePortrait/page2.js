if (window.VarCurrentView) VarCurrentView.set('PhonePortrait');
function init_PhonePortrait() {
	if ( rcdObj.view != 'PhonePortrait' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_PhonePortrait() {
	if ( rcdObj.view != 'PhonePortrait' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
image7.rcdData.att_PhonePortrait = 
{
	innerHtml:	"<img id=\"tobj7Img\" src=\"images/DPO_Back1.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 480px; height: 270px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 480px; height: 270px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"7",
	htmlId:		"tobj7",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_Back1"
	},
	objData:	{"a":[0,288,0,[0,0,480,270]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
video11.rcdData.att_PhonePortrait = 
{
	innerHtml:	"<div id=\"vid\" style=\"left: 0px; top: 0px; width: 405px; height: 228px; background-color: rgb(0, 0, 0); position: absolute;\"></div>",
	cssText:	"position: absolute; left: 42px; top: 21px; width: 405px; height: 228px; z-index: 2;",
	cssClasses:	"",
	id:		"11",
	htmlId:		"tobj11",
	bInsAnc:	0,
	stdHtml:	'<video id="swftobj11" name="swftobj11" width="100%" height="100%" controls="controls" preload="none" playsinline><source type="video/mp4" src="media/ABI%20DPO%20Academy%20SP1%205%20porques%20(Con%20logos)_1.mp4" /><track kind="subtitles" src="ABI%20DPO%20Academy%20SP1%205%20porques%20(Con%20logos)_1Caption1.vtt" srclang="en" label="On" /></video>',
	iosHtml:	'undefined',
	resource:	'media/ABI DPO Academy SP1 5 porques (Con logos)_1.mp4',
	cwObj:		{
		"name":	"DPO_Academy_SP1",
		"arChld":
	[
		{type:6,on:6,delay:0,name:'OnDoneGoTo',actItem:function(){ trivExitPage('page211.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[64,393504,0,[42,21,405,228,-25]],"bLiveWin":1,"rcdOvr":{"res":0},"desktopRect":{"x":100,"y":57,"width":1080,"height":608},"hasEvents":0,"supportsEvents":true,"initHidden":false,"useNoSkin":false,"cssSkin":"trivantis-whotube-skin.css","includeShim":"","flashStreamer":"","bRollOver":false,"skinHeight":25}
};
rcdObj.rcdData.att_PhonePortrait = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_PhonePortrait = pgWidth_phonePort;
rcdObj.preload_PhonePortrait = ["images/DPO_Back1.jpg"];
rcdObj.pgStyle_PhonePortrait = 'position: absolute; left: 0px; top: 0px; width: 480px; height: 763px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_PhonePortrait = ["#FFFFFF","",0,0,1];

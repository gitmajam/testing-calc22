if (window.VarCurrentView) VarCurrentView.set('TabletPortrait');
function init_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton175.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div id=\"tobj175inner\"><svg viewBox=\"0 0 37 25\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(18.5 12.5)\" style=\"\">\n	<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity:0;filter:alpha(opacity=0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_118_191\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_191&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(18.5 12.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 718px; top: 954px; width: 37px; height: 25px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"175",
	htmlId:		"tobj175",
	bInsAnc:	false,
	cwObj:		{
		"name":	"black1_next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu121.processQuestion();

    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkProcTestSurv',actItem:function(){ processTest(1);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39008,0,[718,954,37,25]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":110,"y":75,"width":60,"height":40},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_191\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_191&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_193\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_over.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_193&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_195\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_clicked.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_195&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_197\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_197&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image119.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<img id=\"tobj119Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 785px; height: 442px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 785px; height: 442px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"119",
	htmlId:		"tobj119",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,785,442]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
shape120.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div id=\"tobj120inner\"><svg viewBox=\"0 0 411 277\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(205.5 138.5)\" style=\"\">\n	<path d=\"M 0 0 L 411 0 L 411 277 L 0 277 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84); pointer-events: auto;\" transform=\"translate(0 0) translate(-205.5, -138.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(205.5 138.5)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"38.399999040000004\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84);\">\n			<tspan x=\"0\" y=\"12.1\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 187px; top: 135px; width: 411px; height: 277px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"120",
	htmlId:		"tobj120",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,288,0,[186.99999999999997,135.00000000000006,411,277]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":305,"y":135,"width":670,"height":451},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
qu121.rcdData.att_TabletPortrait = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu121",
	bInsAnc:	undefined,
	cwObj:		{
		"crLineColor":	"",
		"questType":	2,
		"dwQuestFlags":	0,
		"doImmFeedback":	0,
		"maxAllowedAttempts":	0,
		"arrAns":	["\\u0050\\u0072\\u006F\\u0070\\u006F\\u006E\\u0065\\u0072\\u0020\\u0075\\u006E\\u0061\\u0020\\u0073\\u006F\\u006C\\u0075\\u0063\\u0069\\u0026\\u006F\\u0061\\u0063\\u0075\\u0074\\u0065\\u003B\\u006E\\u0020\\u0065\\u0066\\u0069\\u0063\\u0061\\u007A\\u002E"],
		"correctFeedbackFunc":	0,
		"incorrectFeedbackFunc":	0,
		"attemptsFeedbackFunc":	0,
		"varQuest":	VarQuestion_121
	},
	objData:	{"a":[0,32,0,[]]}
};
text122.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 228px; min-height: 20px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 228px; min-height: 20px;\"><p style=\"text-align: center;\"><span style=\"font-size:28pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">Conocer la causa raíz nos permite...</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 50px; top: 100px; width: 228px; height: 20px; z-index: 3;",
	cssClasses:	"",
	id:		"122",
	htmlId:		"tobj122",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[50,100,228,20]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":305,"y":173,"width":669,"height":85},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text123.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 206px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 206px; min-height: 20px;\"><label for=\"rad124\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:20pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">Llenar el formato correctamente.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 79px; top: 130px; width: 206px; height: 20px; z-index: 4;",
	cssClasses:	"",
	id:		"123",
	htmlId:		"tobj123",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[79,130,206,20]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":449,"y":280,"width":603,"height":44},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio124.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad124\" name=\"rad121\" value=\"Llenar el formato correctamente.\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad124\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 50px; top: 130px; width: 36px; height: 36px; z-index: 5;",
	cssClasses:	"",
	id:		"124",
	htmlId:		"tobj124",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[50,130,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":396,"y":275,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text125.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 234px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 234px; min-height: 20px;\"><label for=\"rad126\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:20pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">Proponer una solución eficaz.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 79px; top: 160px; width: 234px; height: 20px; z-index: 6;",
	cssClasses:	"",
	id:		"125",
	htmlId:		"tobj125",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[79,160,234,20]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":449,"y":364,"width":522,"height":41},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio126.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad126\" name=\"rad121\" value=\"Proponer una soluci&amp;oacute;n eficaz.\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad126\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 50px; top: 160px; width: 36px; height: 36px; z-index: 7;",
	cssClasses:	"",
	id:		"126",
	htmlId:		"tobj126",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[50,160,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":396,"y":358,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text127.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 188px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 188px; min-height: 20px;\"><label for=\"rad128\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:20pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">Mejorar el ambiente del equipo.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 79px; top: 190px; width: 188px; height: 20px; z-index: 8;",
	cssClasses:	"",
	id:		"127",
	htmlId:		"tobj127",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[79,190,188,20]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":449,"y":453,"width":543,"height":43},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio128.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad128\" name=\"rad121\" value=\"Mejorar el ambiente del equipo.\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad128\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 50px; top: 190px; width: 36px; height: 36px; z-index: 9;",
	cssClasses:	"",
	id:		"128",
	htmlId:		"tobj128",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[50,190,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":396,"y":448,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
rcdObj.rcdData.att_TabletPortrait = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletPortrait = pgWidth_tabletPort;
rcdObj.preload_TabletPortrait = ["images/DPO_back6.jpg","images/black1_next_63_normal.gif","images/black1_next_63_over.gif","images/black1_next_63_clicked.gif"];
rcdObj.pgStyle_TabletPortrait = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 1000px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletPortrait = ["#FFFFFF","",0,0,1];

if (window.VarCurrentView) VarCurrentView.set('PhoneLandscape');
function init_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton175.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj175inner\"><svg viewBox=\"0 0 37 25\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(18.5 12.5)\" style=\"\">\n	<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity:0;filter:alpha(opacity=0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_118_227\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_227&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(18.5 12.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 718px; top: 404px; width: 37px; height: 25px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"175",
	htmlId:		"tobj175",
	bInsAnc:	false,
	cwObj:		{
		"name":	"black1_next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu121.processQuestion();

    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkProcTestSurv',actItem:function(){ processTest(1);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39008,0,[718,404,37,25]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":110,"y":75,"width":60,"height":40},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_227\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_227&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_229\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_over.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_229&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_231\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_clicked.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_231&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(18.5 12.5)\" style=\"\">\n\t<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_118_233\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"37\" height=\"25\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 37 0 L 37 25 L 0 25 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_118_233&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-18.5, -12.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(18.5 12.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"12.79999968\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"4.03\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image119.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<img id=\"tobj119Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 785px; height: 450px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 785px; height: 450px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"119",
	htmlId:		"tobj119",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,785,450]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
shape120.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj120inner\"><svg viewBox=\"0 0 504 339\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(252 169.5)\" style=\"\">\n	<path d=\"M 0 0 L 504 0 L 504 339 L 0 339 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84); pointer-events: auto;\" transform=\"translate(0 0) translate(-252, -169.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(252 169.5)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"38.399999040000004\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84);\">\n			<tspan x=\"0\" y=\"12.1\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 141px; top: 56px; width: 504px; height: 339px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"120",
	htmlId:		"tobj120",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,288,0,[140.99999999999997,56.00000000000006,504,339]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":289,"y":124,"width":702,"height":472},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
qu121.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu121",
	bInsAnc:	undefined,
	cwObj:		{
		"crLineColor":	"",
		"questType":	2,
		"dwQuestFlags":	0,
		"doImmFeedback":	0,
		"maxAllowedAttempts":	0,
		"arrAns":	["\\u0045\\u006E\\u0020\\u0054\\u0065\\u0061\\u006D\\u0020\\u0052\\u006F\\u006F\\u006D\\u0073\\u0020\\u0068\\u0061\\u0079\\u0020\\u0074\\u0061\\u0062\\u006C\\u0065\\u0072\\u006F\\u0020\\u0070\\u0061\\u0072\\u0061\\u0020\\u0035\\u0020\\u0070\\u006F\\u0072\\u0071\\u0075\\u0026\\u0065\\u0061\\u0063\\u0075\\u0074\\u0065\\u003B\\u0073\\u002C\\u0020\\u0079\\u0020\\u0073\\u0065\\u0020\\u006C\\u006C\\u0065\\u006E\\u0061\\u006E\\u0020\\u0064\\u0065\\u0020\\u0069\\u007A\\u0071\\u0075\\u0069\\u0065\\u0072\\u0064\\u0061\\u0020\\u0061\\u0020\\u0064\\u0065\\u0072\\u0065\\u0063\\u0068\\u0061\\u002E"],
		"correctFeedbackFunc":	0,
		"incorrectFeedbackFunc":	0,
		"attemptsFeedbackFunc":	0,
		"varQuest":	VarQuestion_121
	},
	objData:	{"a":[0,32,0,[]]}
};
text122.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 501px; min-height: 68px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 501px; min-height: 68px;\"><p style=\"text-align: center;\"><span style=\"font-size:25pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">¿Recuerdas la idea número 3?</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 144px; top: 94px; width: 501px; height: 68px; z-index: 3;",
	cssClasses:	"",
	id:		"122",
	htmlId:		"tobj122",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[144,94,501,68]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":313,"y":152,"width":659,"height":85},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text123.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 426px; min-height: 60px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 426px; min-height: 60px;\"><label for=\"rad124\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:15pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">No hay realmente una recomendación para llenar el formato de 5 porqués</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 214px; top: 190px; width: 426px; height: 60px; z-index: 4;",
	cssClasses:	"",
	id:		"123",
	htmlId:		"tobj123",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[214,190,426,60]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":394,"y":255,"width":557,"height":77},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio124.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad124\" name=\"rad121\" value=\"No hay realmente una recomendaci&amp;oacute;n para llenar el formato de 5 porqu&amp;eacute;s\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad124\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 167px; top: 186px; width: 36px; height: 36px; z-index: 5;",
	cssClasses:	"",
	id:		"124",
	htmlId:		"tobj124",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[167,186,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":250,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text125.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 414px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 414px; min-height: 57px;\"><label for=\"rad126\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:15pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">En Team Rooms hay tablero para 5 porqués, y se llenan de izquierda a derecha.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 214px; top: 264px; width: 414px; height: 57px; z-index: 6;",
	cssClasses:	"",
	id:		"125",
	htmlId:		"tobj125",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[214,264,414,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":394,"y":375,"width":591,"height":100},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio126.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad126\" name=\"rad121\" value=\"En Team Rooms hay tablero para 5 porqu&amp;eacute;s, y se llenan de izquierda a derecha.\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad126\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 167px; top: 259px; width: 36px; height: 36px; z-index: 7;",
	cssClasses:	"",
	id:		"126",
	htmlId:		"tobj126",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[167,259,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":369,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text127.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 410px; min-height: 57px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 410px; min-height: 57px;\"><label for=\"rad128\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:15pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">El diagrama de Ishikawa sustituye al análisis de causa raíz.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 214px; top: 334px; width: 410px; height: 57px; z-index: 8;",
	cssClasses:	"",
	id:		"127",
	htmlId:		"tobj127",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[214,334,410,57]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":394,"y":492,"width":557,"height":77},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio128.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad128\" name=\"rad121\" value=\"El diagrama de Ishikawa sustituye al an&amp;aacute;lisis de causa ra&amp;iacute;z.\" onclick=\"VarQuestion_121.set(this.value);qu121.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad128\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 167px; top: 331px; width: 36px; height: 36px; z-index: 9;",
	cssClasses:	"",
	id:		"128",
	htmlId:		"tobj128",
	bInsAnc:	0,
	fieldsetId:	'fset121',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[167,331,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":483,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
rcdObj.rcdData.att_PhoneLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_PhoneLandscape = pgWidth_phoneLand;
rcdObj.preload_PhoneLandscape = ["images/DPO_back6.jpg","images/black1_next_63_normal.gif","images/black1_next_63_over.gif","images/black1_next_63_clicked.gif"];
rcdObj.pgStyle_PhoneLandscape = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 450px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_PhoneLandscape = ["#FFFFFF","",0,0,1];

if (window.VarCurrentView) VarCurrentView.set('TabletLandscape');
function init_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton169.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj169inner\"><svg viewBox=\"0 0 47 32\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(23.5 16)\" style=\"\">\n	<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity:0;filter:alpha(opacity=0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_100_195\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_100_195&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(23.5 16)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 922px; top: 603px; width: 47px; height: 32px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"169",
	htmlId:		"tobj169",
	bInsAnc:	false,
	cwObj:		{
		"name":	"black1_next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu103.processQuestion();

    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page118.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39008,0,[922,603,47,32]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":110,"y":75,"width":60,"height":40},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_100_195\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_100_195&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_100_197\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_over.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_100_197&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_100_199\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_clicked.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_100_199&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_100_201\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_100_201&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image101.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<img id=\"tobj101Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 568px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 568px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"101",
	htmlId:		"tobj101",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,1009,568]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
shape102.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj102inner\"><svg viewBox=\"0 0 553 372\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(276.5 186)\" style=\"\">\n	<path d=\"M 0 0 L 553 0 L 553 372 L 0 372 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84); pointer-events: auto;\" transform=\"translate(0 0) translate(-276.5, -186) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(276.5 186)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"47.9999988\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84);\">\n			<tspan x=\"0\" y=\"15.12\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 228px; top: 98px; width: 553px; height: 372px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"102",
	htmlId:		"tobj102",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,288,0,[227.99999999999994,98.00000000000006,553,372]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":289,"y":124,"width":702,"height":472},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
qu103.rcdData.att_TabletLandscape = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu103",
	bInsAnc:	undefined,
	cwObj:		{
		"crLineColor":	"",
		"questType":	2,
		"dwQuestFlags":	0,
		"doImmFeedback":	0,
		"maxAllowedAttempts":	0,
		"arrAns":	["\\u0053\\u0065\\u0020\\u0075\\u0073\\u0061\\u006E\\u0020\\u0074\\u0061\\u0062\\u006C\\u0065\\u0072\\u006F\\u0073\\u0020\\u0070\\u0061\\u0072\\u0061\\u0020\\u0064\\u0061\\u0072\\u006C\\u0065\\u0020\\u0076\\u0069\\u0073\\u0069\\u0062\\u0069\\u006C\\u0069\\u0064\\u0061\\u0064\\u0020\\u0061\\u0020\\u006C\\u006F\\u0073\\u0020\\u0070\\u0072\\u006F\\u0062\\u006C\\u0065\\u006D\\u0061\\u0073\\u002E"],
		"correctFeedbackFunc":	0,
		"incorrectFeedbackFunc":	0,
		"attemptsFeedbackFunc":	0,
		"varQuest":	VarQuestion_103
	},
	objData:	{"a":[0,32,0,[]]}
};
text104.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 519px; min-height: 67px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 519px; min-height: 67px;\"><p style=\"text-align: center;\"><span style=\"font-size:28pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">¿Recuerdas la idea número 2?</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 247px; top: 120px; width: 519px; height: 67px; z-index: 3;",
	cssClasses:	"",
	id:		"104",
	htmlId:		"tobj104",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[247,120,519,67]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":313,"y":152,"width":659,"height":85},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text105.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 439px; min-height: 61px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 439px; min-height: 61px;\"><label for=\"rad106\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:22pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">Los 5 porqués son un método de solución de problemas</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 318px; top: 201px; width: 439px; height: 61px; z-index: 4;",
	cssClasses:	"",
	id:		"105",
	htmlId:		"tobj105",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[318,201,439,61]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":404,"y":255,"width":557,"height":77},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio106.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad106\" name=\"rad103\" value=\"Los 5 porqu&amp;eacute;s son un m&amp;eacute;todo de soluci&amp;oacute;n de problemas\" onclick=\"VarQuestion_103.set(this.value);qu103.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad106\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 272px; top: 197px; width: 36px; height: 36px; z-index: 5;",
	cssClasses:	"",
	id:		"106",
	htmlId:		"tobj106",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[272,197,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":250,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text107.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 439px; min-height: 61px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 439px; min-height: 61px;\"><label for=\"rad108\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:22pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">La causa raíz puede llegar a ser la solución en sí misma</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 318px; top: 296px; width: 439px; height: 61px; z-index: 6;",
	cssClasses:	"",
	id:		"107",
	htmlId:		"tobj107",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[318,296,439,61]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":404,"y":375,"width":557,"height":77},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio108.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad108\" name=\"rad103\" value=\"La causa ra&amp;iacute;z puede llegar a ser la soluci&amp;oacute;n en s&amp;iacute; misma\" onclick=\"VarQuestion_103.set(this.value);qu103.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad108\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 272px; top: 291px; width: 36px; height: 36px; z-index: 7;",
	cssClasses:	"",
	id:		"108",
	htmlId:		"tobj108",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[272,291,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":369,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text109.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 439px; min-height: 61px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 439px; min-height: 61px;\"><label for=\"rad110\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:22pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">Se usan tableros para darle visibilidad a los problemas.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 318px; top: 388px; width: 439px; height: 61px; z-index: 8;",
	cssClasses:	"",
	id:		"109",
	htmlId:		"tobj109",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[318,388,439,61]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":404,"y":492,"width":557,"height":77},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio110.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad110\" name=\"rad103\" value=\"Se usan tableros para darle visibilidad a los problemas.\" onclick=\"VarQuestion_103.set(this.value);qu103.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad110\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 272px; top: 381px; width: 36px; height: 36px; z-index: 9;",
	cssClasses:	"",
	id:		"110",
	htmlId:		"tobj110",
	bInsAnc:	0,
	fieldsetId:	'fset103',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[272,381,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":345,"y":483,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
rcdObj.rcdData.att_TabletLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletLandscape = pgWidth_tabletLand;
rcdObj.preload_TabletLandscape = ["images/DPO_back6.jpg","images/black1_next_63_normal.gif","images/black1_next_63_over.gif","images/black1_next_63_clicked.gif"];
rcdObj.pgStyle_TabletLandscape = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletLandscape = ["#FFFFFF","",0,0,1];

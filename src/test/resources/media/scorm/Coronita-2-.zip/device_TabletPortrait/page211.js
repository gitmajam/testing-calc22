if (window.VarCurrentView) VarCurrentView.set('TabletPortrait');
function init_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletPortrait() {
	if ( rcdObj.view != 'TabletPortrait' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
image212.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<img id=\"tobj212Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 785px; height: 442px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 785px; height: 442px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"212",
	htmlId:		"tobj212",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,785,442]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
og209.rcdData.att_TabletPortrait = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og209",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape201.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div id=\"tobj201inner\"><svg viewBox=\"0 0 773 429\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(386.5 214.5)\" style=\"\">\n	<path d=\"M 0 0 L 773 0 L 773 429 L 0 429 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54); pointer-events: auto;\" transform=\"translate(0 0) translate(-386.5, -214.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(386.5 214.5)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"38.399999040000004\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54);\">\n			<tspan x=\"0\" y=\"12.1\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 6px; top: 10px; visibility: hidden; position: absolute; width: 773px; height: 429px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"201",
	htmlId:		"tobj201",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,5.999999999999943,10.000000000000085,1,0],[5.999999999999943,10.000000000000085,773,429]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":10,"y":10,"width":1260,"height":700},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text202.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 626px; min-height: 240px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 616px; min-height: 230px;\"><p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt; font-family: AzoSans-Bold, sans-serif; color: rgb(255, 255, 255);\">Ahora vamos a responder tres preguntas.</span></p>\n\n<p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt;\"><span style=\"font-family: AzoSans-Bold, sans-serif; font-size:36pt;\"><span style=\"color: rgb(255, 255, 255);\">Para avanzar a la siguiente actividad debes contestarlas todas correctamente.</span><br>\n<span style=\"color: rgb(255, 255, 255);\">Tienes&nbsp; &nbsp; &nbsp; &nbsp;intentos para lograrlo.</span></span></span></p></div></div>",
	cssText:	"left: 80px; top: 164px; visibility: hidden; position: absolute; width: 626px; height: 240px; z-index: 3;",
	cssClasses:	"",
	id:		"202",
	htmlId:		"tobj202",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,80,164,1,0],[80,164,626,240]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":164,"width":1021,"height":392},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text220.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 51px; min-height: 36px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 41px; min-height: 26px;\"><p style=\"text-align: center;\"><span style=\"font-size:36pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\"><span style=\"color: rgb(255, 255, 255);\">&nbsp;</span></span></p></div></div>",
	cssText:	"left: 259px; top: 404px; visibility: hidden; position: absolute; width: 51px; height: 36px; z-index: 4;",
	cssClasses:	"",
	id:		"220",
	htmlId:		"tobj220",
	bInsAnc:	0,
	cwObj:		{
		"name":	"variable",
		"arChld":
	[
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('1'))text220.changeContents( "3" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('2'))text220.changeContents( "2" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(Varintentos.equals('3'))text220.changeContents( "1" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,259,404,1,0],[259,404,51,36]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":423,"y":404,"width":83,"height":59},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton203.rcdData.att_TabletPortrait = 
{
	innerHtml:	"<div id=\"tobj203inner\"><svg viewBox=\"0 0 150 53\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(75 26.5)\" style=\"\">\n	<path d=\"M 13 0 L 136 0 A 13 13 0 0 1 149 13 L 149 39 A 13 13 0 0 1 136 52 L 13 52 A 13 13 0 0 1 0 39 L 0 13 A 13 13 0 0 1 13 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-74.5, -26) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(75 26.5)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"25.771811436241617\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-48.62\" y=\"8.12\" fill=\"#FFFFFF\">Aceptar</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 317.5px; top: 527.5px; visibility: hidden; position: absolute; width: 150px; height: 53px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"203",
	htmlId:		"tobj203",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnEvaluacion",
		"arChld":
	[
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page39.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[36,32864,[37,0,6,0,0,0,317.5,527.5,1,0],[317.5,527.5,150,53]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":519,"y":528,"width":244,"height":86},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(75 26.5)\" style=\"\">\n\t<path d=\"M 13 0 L 136 0 A 13 13 0 0 1 149 13 L 149 39 A 13 13 0 0 1 136 52 L 13 52 A 13 13 0 0 1 0 39 L 0 13 A 13 13 0 0 1 13 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-74.5, -26) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75 26.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"25.771811436241617\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.62\" y=\"8.12\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(75 26.5)\" style=\"\">\n\t<path d=\"M 13 0 L 136 0 A 13 13 0 0 1 149 13 L 149 39 A 13 13 0 0 1 136 52 L 13 52 A 13 13 0 0 1 0 39 L 0 13 A 13 13 0 0 1 13 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-74.5, -26) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75 26.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"25.771811436241617\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.62\" y=\"8.12\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(75 26.5)\" style=\"\">\n\t<path d=\"M 13 0 L 136 0 A 13 13 0 0 1 149 13 L 149 39 A 13 13 0 0 1 136 52 L 13 52 A 13 13 0 0 1 0 39 L 0 13 A 13 13 0 0 1 13 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-74.5, -26) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75 26.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"25.771811436241617\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.62\" y=\"8.12\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(75 26.5)\" style=\"\">\n\t<path d=\"M 13 0 L 136 0 A 13 13 0 0 1 149 13 L 149 39 A 13 13 0 0 1 136 52 L 13 52 A 13 13 0 0 1 0 39 L 0 13 A 13 13 0 0 1 13 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-74.5, -26) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75 26.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"25.771811436241617\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-48.62\" y=\"8.12\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
rcdObj.rcdData.att_TabletPortrait = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletPortrait = pgWidth_tabletPort;
rcdObj.preload_TabletPortrait = ["images/DPO_back6.jpg"];
rcdObj.pgStyle_TabletPortrait = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 1000px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletPortrait = ["#FFFFFF","",0,0,1];

if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton147.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj147inner\"><svg viewBox=\"0 0 160 47\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(80 23.5)\" style=\"\">\n	<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(80 23.5)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-48.21\" y=\"6.72\" fill=\"#FFFFFF\">Ver video</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 431.5px; top: 549.5px; width: 160px; height: 47px; z-index: 3; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"147",
	htmlId:		"tobj147",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnVideo",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkResetTestSurv',actItem:function(){ ResetTest_test32(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page2.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32864,0,[431.5,549.5,160,47]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":432,"y":550,"width":160,"height":47},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.21\" y=\"6.72\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.21\" y=\"6.72\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-48.21\" y=\"6.72\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-48.21\" y=\"6.72\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
textbutton149.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj149inner\"><svg viewBox=\"0 0 160 47\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(80 23.5)\" style=\"\">\n	<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(80 23.5)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-54.15\" y=\"6.72\" fill=\"#FFFFFF\">Evaluación</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 729.5px; top: 549.5px; width: 160px; height: 47px; z-index: 4; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"149",
	htmlId:		"tobj149",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnEvaluacion",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkResetTestSurv',actItem:function(){ ResetTest_test32(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page211.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32864,0,[729.5,549.5,160,47]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":730,"y":550,"width":160,"height":47},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-54.15\" y=\"6.72\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-54.15\" y=\"6.72\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-54.15\" y=\"6.72\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(80 23.5)\" style=\"\">\n\t<path d=\"M 11.5 0 L 147.5 0 A 11.5 11.5 0 0 1 159 11.5 L 159 34.5 A 11.5 11.5 0 0 1 147.5 46 L 11.5 46 A 11.5 11.5 0 0 1 0 34.5 L 0 11.5 A 11.5 11.5 0 0 1 11.5 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-79.5, -23) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(80 23.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"21.3333328\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-54.15\" y=\"6.72\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image138.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj138Img\" src=\"images/DPO_back3.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1280px; height: 720px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1280px; height: 720px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"138",
	htmlId:		"tobj138",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back3"
	},
	objData:	{"a":[0,32,0,[0,0,1280,720]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
text146.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 727px; min-height: 269px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 717px; min-height: 259px;\"><p style=\"text-align: center;\"><span style=\"font-size:48pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">No lograste contestar todas las preguntas correctamente</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 277px; top: 251px; width: 727px; height: 269px; z-index: 2;",
	cssClasses:	"",
	id:		"146",
	htmlId:		"tobj146",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[0,32,0,[277,251,727,269]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":277,"y":251,"width":727,"height":269},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	7
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/DPO_back3.jpg"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1280px; height: 720px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","",0,0,1];

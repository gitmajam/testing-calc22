if (window.VarCurrentView) VarCurrentView.set('PhoneLandscape');
function init_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_PhoneLandscape() {
	if ( rcdObj.view != 'PhoneLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton147.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj147inner\"><svg viewBox=\"0 0 151 49\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(75.5 24.5)\" style=\"\">\n	<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(75.5 24.5)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"26.41493267296\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-59.69\" y=\"8.32\" fill=\"#FFFFFF\">Ver video</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 200.5px; top: 338.5px; width: 151px; height: 49px; z-index: 3; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"147",
	htmlId:		"tobj147",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnVideo",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkResetTestSurv',actItem:function(){ ResetTest_test32(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page2.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32864,0,[200.5,338.5,151,49]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":432,"y":550,"width":160,"height":47},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"26.41493267296\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-59.69\" y=\"8.32\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"26.41493267296\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-59.69\" y=\"8.32\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"26.41493267296\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-59.69\" y=\"8.32\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"26.41493267296\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-59.69\" y=\"8.32\" fill=\"#FFFFFF\">Ver video</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
textbutton149.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div id=\"tobj149inner\"><svg viewBox=\"0 0 151 49\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(75.5 24.5)\" style=\"\">\n	<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(75.5 24.5)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"22.978843869973332\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-58.31\" y=\"7.24\" fill=\"#FFFFFF\">Evaluación</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 432.5px; top: 341.5px; width: 151px; height: 49px; z-index: 4; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"149",
	htmlId:		"tobj149",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnEvaluacion",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkResetTestSurv',actItem:function(){ ResetTest_test32(); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page211.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32864,0,[432.5,341.5,151,49]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":730,"y":550,"width":160,"height":47},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"22.978843869973332\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-58.31\" y=\"7.24\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"22.978843869973332\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-58.31\" y=\"7.24\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"22.978843869973332\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-58.31\" y=\"7.24\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(75.5 24.5)\" style=\"\">\n\t<path d=\"M 12 0 L 138 0 A 12 12 0 0 1 150 12 L 150 36 A 12 12 0 0 1 138 48 L 12 48 A 12 12 0 0 1 0 36 L 0 12 A 12 12 0 0 1 12 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-75, -24) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(75.5 24.5)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"22.978843869973332\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-58.31\" y=\"7.24\" fill=\"#FFFFFF\">Evaluación</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image138.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<img id=\"tobj138Img\" src=\"images/DPO_back3.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 785px; height: 450px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 785px; height: 450px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"138",
	htmlId:		"tobj138",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back3"
	},
	objData:	{"a":[0,32,0,[0,0,785,450]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
text146.rcdData.att_PhoneLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 507px; min-height: 211px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 497px; min-height: 201px;\"><p style=\"text-align: center;\"><span style=\"font-size:34pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">No lograste contestar todas las preguntas correctamente</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 139px; top: 131px; width: 507px; height: 211px; z-index: 2;",
	cssClasses:	"",
	id:		"146",
	htmlId:		"tobj146",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[0,32,0,[139,131,507,211]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":277,"y":251,"width":727,"height":269},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_PhoneLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_PhoneLandscape = pgWidth_phoneLand;
rcdObj.preload_PhoneLandscape = ["images/DPO_back3.jpg"];
rcdObj.pgStyle_PhoneLandscape = 'position: absolute; left: 0px; top: 0px; width: 785px; height: 450px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_PhoneLandscape = ["#FFFFFF","",0,0,1];

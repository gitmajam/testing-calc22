if (window.VarCurrentView) VarCurrentView.set('TabletLandscape');
function init_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
image212.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<img id=\"tobj212Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 568px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 568px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"212",
	htmlId:		"tobj212",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,1009,568]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
og209.rcdData.att_TabletLandscape = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og209",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape201.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj201inner\"><svg viewBox=\"0 0 993 552\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(496.5 276)\" style=\"\">\n	<path d=\"M 0 0 L 993 0 L 993 552 L 0 552 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54); pointer-events: auto;\" transform=\"translate(0 0) translate(-496.5, -276) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(496.5 276)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"47.9999988\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.54;filter:alpha(opacity=54);\">\n			<tspan x=\"0\" y=\"15.12\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 8px; top: 8px; visibility: hidden; position: absolute; width: 993px; height: 552px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"201",
	htmlId:		"tobj201",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,7.999999999999943,8.000000000000114,1,0],[7.999999999999943,8.000000000000114,993,552]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":10,"y":10,"width":1260,"height":700},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
text202.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 805px; min-height: 309px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 795px; min-height: 299px;\"><p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt; font-family: AzoSans-Bold, sans-serif; color: rgb(255, 255, 255);\">Ahora vamos a responder tres preguntas.</span></p>\n\n<p style=\"line-height: 1.5; margin-top: 0px; margin-bottom: 0px; text-align: center;\"><span style=\"font-size:36pt;\"><span style=\"font-family: AzoSans-Bold, sans-serif; font-size:36pt;\"><span style=\"color: rgb(255, 255, 255);\">Para avanzar a la siguiente actividad debes contestarlas todas correctamente.</span><br>\n<span style=\"color: rgb(255, 255, 255);\">Tienes&nbsp; &nbsp; &nbsp; &nbsp;intentos para lograrlo.</span></span></span></p></div></div>",
	cssText:	"left: 102px; top: 129px; visibility: hidden; position: absolute; width: 805px; height: 309px; z-index: 3;",
	cssClasses:	"",
	id:		"202",
	htmlId:		"tobj202",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,102,129,1,0],[102,129,805,309]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":130,"y":164,"width":1021,"height":392},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text220.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 65px; min-height: 47px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 55px; min-height: 37px;\"><p style=\"text-align: center;\"><span style=\"font-size:36pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\"><span style=\"color: rgb(255, 255, 255);\">&nbsp;</span></span></p></div></div>",
	cssText:	"left: 333px; top: 318px; visibility: hidden; position: absolute; width: 65px; height: 47px; z-index: 4;",
	cssClasses:	"",
	id:		"220",
	htmlId:		"tobj220",
	bInsAnc:	0,
	cwObj:		{
		"name":	"variable",
		"arChld":
	[
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(VarIntentos.equals('1'))text220.changeContents( "3" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(VarIntentos.equals('2'))text220.changeContents( "2" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }},
		{type:6,on:5,delay:0,name:'OnShowChange',actItem:function(){ if(VarIntentos.equals('3'))text220.changeContents( "1" ); else if(typeof pF == 'function') pF();
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[32,32,[37,0,6,0,0,0,333,318,1,0],[333,318,65,47]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":423,"y":404,"width":83,"height":59},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton203.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj203inner\"><svg viewBox=\"0 0 193 68\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(96.5 34)\" style=\"\">\n	<path d=\"M 16.75 0 L 175.25 0 A 16.75 16.75 0 0 1 192 16.75 L 192 50.25 A 16.75 16.75 0 0 1 175.25 67 L 16.75 67 A 16.75 16.75 0 0 1 0 50.25 L 0 16.75 A 16.75 16.75 0 0 1 16.75 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-96, -33.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(96.5 34)\">\n		<text font-family=\"\'AzoSans-Bold\',sans-serif\" font-size=\"32.1666658625\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"-60.67\" y=\"10.13\" fill=\"#FFFFFF\">Aceptar</tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"left: 408.5px; top: 415.5px; visibility: hidden; position: absolute; width: 193px; height: 68px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"203",
	htmlId:		"tobj203",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btnEvaluacion",
		"arChld":
	[
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page39.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[36,32864,[37,0,6,0,0,0,408.5,415.5,1,0],[408.5,415.5,193,68]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":519,"y":528,"width":244,"height":86},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(96.5 34)\" style=\"\">\n\t<path d=\"M 16.75 0 L 175.25 0 A 16.75 16.75 0 0 1 192 16.75 L 192 50.25 A 16.75 16.75 0 0 1 175.25 67 L 16.75 67 A 16.75 16.75 0 0 1 0 50.25 L 0 16.75 A 16.75 16.75 0 0 1 16.75 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-96, -33.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(96.5 34)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"32.1666658625\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.67\" y=\"10.13\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(96.5 34)\" style=\"\">\n\t<path d=\"M 16.75 0 L 175.25 0 A 16.75 16.75 0 0 1 192 16.75 L 192 50.25 A 16.75 16.75 0 0 1 175.25 67 L 16.75 67 A 16.75 16.75 0 0 1 0 50.25 L 0 16.75 A 16.75 16.75 0 0 1 16.75 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(122, 122, 122); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-96, -33.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(96.5 34)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"32.1666658625\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.67\" y=\"10.13\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(96.5 34)\" style=\"\">\n\t<path d=\"M 16.75 0 L 175.25 0 A 16.75 16.75 0 0 1 192 16.75 L 192 50.25 A 16.75 16.75 0 0 1 175.25 67 L 16.75 67 A 16.75 16.75 0 0 1 0 50.25 L 0 16.75 A 16.75 16.75 0 0 1 16.75 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(81, 81, 81); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-96, -33.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(96.5 34)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"32.1666658625\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"-60.67\" y=\"10.13\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(96.5 34)\" style=\"\">\n\t<path d=\"M 16.75 0 L 175.25 0 A 16.75 16.75 0 0 1 192 16.75 L 192 50.25 A 16.75 16.75 0 0 1 175.25 67 L 16.75 67 A 16.75 16.75 0 0 1 0 50.25 L 0 16.75 A 16.75 16.75 0 0 1 16.75 0 Z\" style=\"stroke: rgb(255, 255, 255); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-96, -33.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(96.5 34)\">\n\t\t<text font-family=\"'AzoSans-Bold',sans-serif\" font-size=\"32.1666658625\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"-60.67\" y=\"10.13\" fill=\"#FFFFFF\">Aceptar</tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
rcdObj.rcdData.att_TabletLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletLandscape = pgWidth_tabletLand;
rcdObj.preload_TabletLandscape = ["images/DPO_back6.jpg"];
rcdObj.pgStyle_TabletLandscape = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletLandscape = ["#FFFFFF","",0,0,1];

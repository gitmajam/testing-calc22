if (window.VarCurrentView) VarCurrentView.set('TabletLandscape');
function init_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton163.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj163inner\"><svg viewBox=\"0 0 47 32\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(23.5 16)\" style=\"\">\n	<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity:0;filter:alpha(opacity=0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_39_25\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_39_25&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(23.5 16)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 922px; top: 603px; width: 47px; height: 32px; z-index: 10; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"163",
	htmlId:		"tobj163",
	bInsAnc:	false,
	cwObj:		{
		"name":	"black1_next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcQ',actItem:function(){ qu87.processQuestion();

    if(typeof pF == 'function') pF(); }},
		{type:6,on:2,delay:100,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page100.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,39008,0,[922,603,47,32]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":110,"y":75,"width":60,"height":40},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_39_25\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_39_25&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_39_27\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_over.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_39_27&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_39_29\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_clicked.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_39_29&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(23.5 16)\" style=\"\">\n\t<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_39_31\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"47\" height=\"32\" xlink:href=\"images/black1_next_63_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 47 0 L 47 32 L 0 32 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_39_31&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-23.5, -16) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(23.5 16)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled"}
};
image19.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<img id=\"tobj19Img\" src=\"images/DPO_back6.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 568px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 568px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"19",
	htmlId:		"tobj19",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back6"
	},
	objData:	{"a":[0,32,0,[0,0,1009,568]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
shape99.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div id=\"tobj99inner\"><svg viewBox=\"0 0 553 372\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(276.5 186)\" style=\"\">\n	<path d=\"M 0 0 L 553 0 L 553 372 L 0 372 L 0 0 Z\" style=\"stroke: rgb(0, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(102, 102, 102); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84); pointer-events: auto;\" transform=\"translate(0 0) translate(-276.5, -186) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(276.5 186)\">\n		<text font-family=\"\'Bison Bold\',sans-serif\" font-size=\"47.9999988\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:0.84;filter:alpha(opacity=84);\">\n			<tspan x=\"0\" y=\"15.12\" fill=\"#ffffff\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 228px; top: 98px; width: 553px; height: 372px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"99",
	htmlId:		"tobj99",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle"
	},
	objData:	{"a":[0,288,0,[227.99999999999994,98.00000000000006,553,372]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":289,"y":124,"width":702,"height":472},"bTriggerScreenRdrOnShow":false,"btnState":"disabled"}
};
qu87.rcdData.att_TabletLandscape = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu87",
	bInsAnc:	undefined,
	cwObj:		{
				"crLineColor":	"",
				"questType":	2,
				"dwQuestFlags":	0,
				"doImmFeedback":	0,
				"maxAllowedAttempts":	0,
				"arrAns":	["\\u0038\\u0030\\u0025"],
				"correctFeedbackFunc":	0,
				"incorrectFeedbackFunc":	0,
				"attemptsFeedbackFunc":	0,
				"varQuest":	VarQuestion_1
	},
	objData:	{"a":[0,32,0,[]]}
};
text92.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 474px; min-height: 103px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 474px; min-height: 103px;\"><p style=\"text-align: center;\"><span style=\"font-size:26pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">¿Aproximadamente qué porcentaje de los problemas deberían resolverse en piso?</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 268px; top: 114px; width: 474px; height: 103px; z-index: 3;",
	cssClasses:	"",
	id:		"92",
	htmlId:		"tobj92",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[268,114,474,103]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":340,"y":144,"width":601,"height":131},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text93.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 78px; min-height: 58px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 78px; min-height: 58px;\"><label for=\"rad94\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:26pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">20%</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 466px; top: 240px; width: 78px; height: 58px; z-index: 4;",
	cssClasses:	"",
	id:		"93",
	htmlId:		"tobj93",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[466,240,78,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":591,"y":304,"width":99,"height":73},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio94.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad94\" name=\"rad87\" value=\"20%\" onclick=\"VarQuestion_1.set(this.value);qu87.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad94\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 426px; top: 238px; width: 36px; height: 36px; z-index: 5;",
	cssClasses:	"",
	id:		"94",
	htmlId:		"tobj94",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[426,238,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":540,"y":302,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text95.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 78px; min-height: 58px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 78px; min-height: 58px;\"><label for=\"rad96\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:26pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">80%</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 466px; top: 317px; width: 78px; height: 58px; z-index: 6;",
	cssClasses:	"",
	id:		"95",
	htmlId:		"tobj95",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[466,317,78,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":591,"y":402,"width":99,"height":73},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio96.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad96\" name=\"rad87\" value=\"80%\" onclick=\"VarQuestion_1.set(this.value);qu87.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad96\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 426px; top: 316px; width: 36px; height: 36px; z-index: 7;",
	cssClasses:	"",
	id:		"96",
	htmlId:		"tobj96",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[426,316,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":540,"y":401,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
text97.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 78px; min-height: 58px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 78px; min-height: 58px;\"><label for=\"rad98\" style=\"cursor:\"><p align=\"left\"><span style=\"font-size:26pt; color: rgb(255, 255, 255); font-family: AzoSans-Regular, sans-serif;\">100%</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 466px; top: 402px; width: 78px; height: 58px; z-index: 8;",
	cssClasses:	"",
	id:		"97",
	htmlId:		"tobj97",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[466,402,78,58]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":591,"y":510,"width":99,"height":73},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio98.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 36px; height: 36px;\"><input type=\"radio\" id=\"rad98\" name=\"rad87\" value=\"100%\" onclick=\"VarQuestion_1.set(this.value);qu87.questionUpdated();\" style=\"position: absolute; width: 1px; height: 1px; opacity:0.01;filter:alpha(opacity=1); cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"><label for=\"rad98\" style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(0, 0, 0); background-image: url(&quot;images/SpaceGray_RU.png&quot;); background-repeat: no-repeat; cursor: pointer; position: absolute; background-position: 0px 50%; padding-left: 36px; text-align: left; height: 100%; line-height: 36px;\"></label></div>",
	cssText:	"visibility: inherit; position: absolute; left: 426px; top: 401px; width: 36px; height: 36px; z-index: 9;",
	cssClasses:	"",
	id:		"98",
	htmlId:		"tobj98",
	bInsAnc:	0,
	fieldsetId:	'fset87',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[426,401,36,36]],"rcdOvr":{"res":0},"desktopRect":{"x":540,"y":509,"width":36,"height":36},"formType":1,"dwFormFlags":0}
};
rcdObj.rcdData.att_TabletLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletLandscape = pgWidth_tabletLand;
rcdObj.preload_TabletLandscape = ["images/DPO_back6.jpg","images/black1_next_63_normal.gif","images/black1_next_63_over.gif","images/black1_next_63_clicked.gif"];
rcdObj.pgStyle_TabletLandscape = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletLandscape = ["#FFFFFF","",0,0,1];

if (window.VarCurrentView) VarCurrentView.set('TabletLandscape');
function init_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_TabletLandscape() {
	if ( rcdObj.view != 'TabletLandscape' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
image137.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<img id=\"tobj137Img\" src=\"images/DPO_back3.jpg\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 1009px; height: 568px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 0px; width: 1009px; height: 568px; z-index: 1; border-radius: 0px;",
	cssClasses:	"",
	id:		"137",
	htmlId:		"tobj137",
	bInsAnc:	0,
	cwObj:		{
		"name":	"DPO_back3"
	},
	objData:	{"a":[0,32,0,[0,0,1009,568]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":1280,"height":720}}
};
text154.rcdData.att_TabletLandscape = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; cursor: pointer; width: 665px; min-height: 252px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 655px; min-height: 242px;\"><p style=\"text-align: center;\"><span style=\"font-size:48pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">¡Felicidades!&nbsp;</span></p>\n\n<p style=\"text-align: center;\"><span style=\"font-size:48pt; color: rgb(255, 255, 255); font-family: AzoSans-Bold, sans-serif;\">Completaste la actividad correctamente</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 172px; top: 177px; width: 665px; height: 252px; z-index: 2; cursor: pointer;",
	cssClasses:	"",
	id:		"154",
	htmlId:		"tobj154",
	bInsAnc:	1,
	cwObj:		{
		"name":	"Text Block 1",
		"arChld":
	[
		{type:6,on:2,delay:200,name:'OnMClkExitClose',actItem:function(){ trivLogMsg( 'Action [OnMClkExitClose on Text Block 1] fired!', 4 )
    if( text154.eatOnUp==true ){
        text154.eatOnUp=false;
        return;
    }
    {trivScormQuit(true, 'page1.html', true);} 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,32,0,[172,177,665,252]],"rcdOvr":{"res":0},"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":218,"y":225,"width":844,"height":320},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_TabletLandscape = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"'Arial',sans-serif","lineHeight":"1.15","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	9
};
rcdObj.pgWidth_TabletLandscape = pgWidth_tabletLand;
rcdObj.preload_TabletLandscape = ["images/DPO_back3.jpg"];
rcdObj.pgStyle_TabletLandscape = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-size: auto;'
rcdObj.backgrd_TabletLandscape = ["#FFFFFF","",0,0,1];
